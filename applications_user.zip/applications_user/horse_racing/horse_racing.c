#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <stdlib.h>
#include "horse_racing_icons.h" // Include the icon header file

#define FLIPPER_LCD_WIDTH 128
#define FLIPPER_LCD_HEIGHT 64
#define FINISH_LINE 100

typedef enum {
    GameStateIdle,
    GameStateCountdown,
    GameStateRacing,
    GameStateResult,
} GameState;

typedef struct {
    GameState game_state;
    FuriMutex* mutex;
    uint32_t countdown_start;
    uint32_t race_start;
    uint32_t race_end;
    uint32_t text_delay; // Add this line
    int player_progress;
    int cpu_progress;
    bool new_high_score;
    bool countdown_finished;
    bool exit;
    uint32_t animation_frame; // Add this line
} AppState;

// Draw the background frame
void draw_background(Canvas* canvas) {
    canvas_draw_frame(canvas, 0, 0, FLIPPER_LCD_WIDTH, FLIPPER_LCD_HEIGHT);

    // Draw the finish line
    canvas_draw_line(canvas, FINISH_LINE, 10, FINISH_LINE, FLIPPER_LCD_HEIGHT - 10);
}

// Draw player and CPU progress
void draw_progress(Canvas* canvas, const AppState* app_state) {
    const Icon* player_icon;
    const Icon* cpu_icon;

    if(app_state->game_state < GameStateRacing) {
        // Draw horse at start line
        player_icon = &I_horse_3;
        cpu_icon = &I_horse_3;
    } else {
        // Select the icon based on the animation frame
        player_icon = (app_state->animation_frame < 5) ? &I_horse_1 : &I_horse_2;
        cpu_icon = (app_state->animation_frame < 5) ? &I_horse_1 : &I_horse_2;
    }

    // Draw player horse icon (assuming the icon is 16x16 pixels)
    int player_icon_x = 10 + app_state->player_progress - 8; // Center the icon horizontally
    int player_icon_y = 20 - 3; // Adjust vertically to align with the progress bar
    canvas_draw_icon(canvas, player_icon_x, player_icon_y, player_icon);

    // Draw CPU horse icon (assuming the icon is 16x16 pixels)
    int cpu_icon_x = 10 + app_state->cpu_progress - 8; // Center the icon horizontally
    int cpu_icon_y = 40 - 3; // Adjust vertically to align with the progress bar
    canvas_draw_icon(canvas, cpu_icon_x, cpu_icon_y, cpu_icon);
}

// Draw game state text
void draw_text(Canvas* canvas, AppState* app_state) {
    char buffer[32];
    uint32_t current_time = furi_get_tick();
    uint32_t elapsed = current_time - app_state->countdown_start;

    if(app_state->game_state == GameStateIdle) {
        snprintf(buffer, sizeof(buffer), "Press OK to start");
        canvas_draw_str(canvas, 10, 10, buffer);
    } else if(app_state->game_state == GameStateCountdown) {
        if(elapsed < furi_ms_to_ticks(1000)) {
            snprintf(buffer, sizeof(buffer), "READY");
        } else if(elapsed < furi_ms_to_ticks(2500 + rand() % 3500)) {
            snprintf(buffer, sizeof(buffer), "SET");
        } else {
            snprintf(buffer, sizeof(buffer), "RACE");
            app_state->game_state = GameStateRacing;
            app_state->race_start = furi_get_tick(); // Record race start time
            app_state->text_delay =
                app_state->race_start + furi_ms_to_ticks(1000); // Add delay of 1 second
        }
        canvas_draw_str(canvas, 50, 10, buffer);
    } else if(app_state->game_state == GameStateRacing) {
        if(current_time < app_state->text_delay) {
            snprintf(buffer, sizeof(buffer), "RACE");
            canvas_draw_str(canvas, 50, 10, buffer);
        }
    } else if(app_state->game_state == GameStateResult) {
        if(app_state->player_progress >= FINISH_LINE) {
            snprintf(buffer, sizeof(buffer), "You Win!");
        } else {
            snprintf(buffer, sizeof(buffer), "CPU Wins!");
        }
        canvas_draw_str(canvas, 10, 10, buffer);

        // Display race time in seconds with two decimal places
        uint32_t race_time_ms = app_state->race_end - app_state->race_start;
        double race_time_s = race_time_ms / 1000.0;
        snprintf(buffer, sizeof(buffer), "Time: %.2fs", race_time_s);
        canvas_draw_str(canvas, 10, 20, buffer);
    }

    if(app_state->new_high_score) {
        canvas_draw_str(canvas, 10, 40, "New High Score!");
    }
}

// The render callback function that is called to render the screen.
// This is updated in the main loop through view_port_update
static void app_render_callback(Canvas* const canvas, void* ctx) {
    furi_assert(ctx);
    AppState* app_state = ctx;
    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    draw_background(canvas);
    draw_progress(canvas, app_state);
    draw_text(canvas, app_state);

    furi_mutex_release(app_state->mutex);
}

// The input callback function that is called when an input event occurs.
static void app_input_callback(InputEvent* input_event, void* ctx) {
    furi_assert(ctx);
    AppState* app_state = ctx;

    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    if(input_event->type == InputTypePress && input_event->key == InputKeyBack) {
        if(app_state->game_state == GameStateResult) {
            app_state->game_state = GameStateIdle;
        } else {
            app_state->exit = true;
        }
    } else if(input_event->type == InputTypePress && input_event->key == InputKeyOk) {
        if(app_state->game_state == GameStateIdle) {
            app_state->game_state = GameStateCountdown;
            app_state->countdown_start = furi_get_tick();
        } else if(app_state->game_state == GameStateRacing) {
            uint32_t current_time = furi_get_tick();
            if(current_time >= app_state->text_delay) {
                app_state->player_progress += 1;
                if(app_state->player_progress >= FINISH_LINE) {
                    app_state->game_state = GameStateResult;
                    app_state->race_end = furi_get_tick(); // Record race end time
                    app_state->new_high_score = app_state->player_progress <
                                                    app_state->cpu_progress ||
                                                app_state->cpu_progress == 0;
                }
            }
        }
    }

    furi_mutex_release(app_state->mutex);
}

// Allocate and initialize the application state
AppState* app_state_alloc() {
    AppState* app_state = malloc(sizeof(AppState));
    if(!app_state) return NULL;

    app_state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    if(!app_state->mutex) {
        free(app_state);
        return NULL;
    }

    app_state->game_state = GameStateIdle;
    app_state->countdown_start = 0;
    app_state->race_start = 0;
    app_state->race_end = 0;
    app_state->text_delay = 0; // Initialize text delay
    app_state->player_progress = 0;
    app_state->cpu_progress = 0;
    app_state->new_high_score = false;
    app_state->countdown_finished = false;
    app_state->exit = false;
    app_state->animation_frame = 0; // Initialize animation frame

    return app_state;
}

int32_t horse_racing_app(void* p) {
    UNUSED(p);
    int32_t return_code = 0;

    // Allocate and initialize the application state
    AppState* app_state = app_state_alloc();
    if(!app_state) return 255;

    // Allocate a new view port
    ViewPort* view_port = view_port_alloc();
    // Set the draw callback function for the view port to `app_render_callback` and pass the application state as context.
    view_port_draw_callback_set(view_port, app_render_callback, app_state);
    // Set the input callback function for the view port to `app_input_callback` and pass the application state as context.
    view_port_input_callback_set(view_port, app_input_callback, app_state);

    // Open the GUI record and add the view port to the GUI in full-screen mode.
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    // Enter an infinite loop that will continue until `app_state->exit` is set to true.
    while(!app_state->exit) {
        static uint32_t count = 0;

        // Game logic
        if(app_state->game_state == GameStateRacing) {
            uint32_t current_time = furi_get_tick();
            if(current_time >= app_state->text_delay) {
                if(count % 2 == 0) { // Adjust the frequency of CPU progress updates
                    app_state->cpu_progress += rand() % 3;
                }
                if(app_state->cpu_progress >= FINISH_LINE) {
                    app_state->game_state = GameStateResult;
                    app_state->race_end = furi_get_tick(); // Record race end time
                    app_state->new_high_score = false;
                }
                count++;
            }
        }

        // Update animation frame
        app_state->animation_frame =
            (app_state->animation_frame + 1) % 10; // Cycle between 0 and 9

        view_port_update(
            view_port); // Updates the view port, causing the render callback to be called.
        furi_delay_ms(80); // Add delay to slow down the loop
    }

    // Clean up resources
    view_port_enabled_set(view_port, false);
    gui_remove_view_port(gui, view_port);
    furi_record_close(RECORD_GUI);
    view_port_free(view_port);
    furi_mutex_free(app_state->mutex);
    free(app_state);

    return return_code; // Returns the return code, which is 0 if everything was successful.
}
