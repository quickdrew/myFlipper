#include "application.h"

typedef enum {
    GameSelectNone,
    GameSelectRace,
    GameSelectDuel,
} GameSelect;

typedef struct {
    GameSelect game_select;
    FuriMutex* mutex;
    bool exit;
    int x;
    int y;
    bool start_race;
    bool start_duel;
} TownAppState;

void town_draw_background(Canvas* canvas) {
    canvas_draw_frame(canvas, 0, 0, FLIPPER_LCD_WIDTH, FLIPPER_LCD_HEIGHT);

    canvas_draw_icon(canvas, 0, 0, &I_town_background);
}

void town_draw_player(Canvas* canvas, const TownAppState* app_state) {
    const Icon* player_icon;
    char buffer[32];

    player_icon = &I_town_player;
    canvas_draw_icon(canvas, app_state->x, app_state->y, player_icon);
    snprintf(buffer, sizeof(buffer), "Position %i, %i", app_state->x, app_state->y);
    canvas_draw_str(canvas, 10, 10, buffer);
}

void town_select_mode(Canvas* canvas, TownAppState* app_state) {
    char buffer[32];

    if(app_state->x > 30 && app_state->x < 40 && app_state->y > 10 && app_state->y < 20) {
        app_state->game_select = GameSelectRace;
        snprintf(buffer, sizeof(buffer), "Press OK to Race!");
    } else if(app_state->x > 60 && app_state->x < 70 && app_state->y > 17 && app_state->y < 22) {
        app_state->game_select = GameSelectDuel;
        snprintf(buffer, sizeof(buffer), "Press OK to Duel!");
    } else {
        app_state->game_select = GameSelectNone;
    }

    canvas_draw_str(canvas, 10, 10, buffer);
}

// The render callback function that is called to render the screen.
// This is updated in the main loop through view_port_update
static void town_render_callback(Canvas* const canvas, void* ctx) {
    furi_assert(ctx);
    TownAppState* app_state = ctx;
    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    town_draw_background(canvas);
    town_draw_player(canvas, app_state);
    town_select_mode(canvas, app_state);

    furi_mutex_release(app_state->mutex);
}

// The input callback function that is called when an input event occurs.
static void town_input_callback(InputEvent* input_event, void* ctx) {
    furi_assert(ctx);
    TownAppState* app_state = ctx;

    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    // Check for both press and repeat events
    if(input_event->type == InputTypePress || input_event->type == InputTypeRepeat) {
        if(input_event->key == InputKeyBack) {
            app_state->exit = true;
        } else if(input_event->key == InputKeyUp) {
            app_state->y -= 2; // Move up
        } else if(input_event->key == InputKeyDown) {
            app_state->y += 2; // Move down
        } else if(input_event->key == InputKeyLeft) {
            app_state->x -= 2; // Move left
        } else if(input_event->key == InputKeyRight) {
            app_state->x += 2; // Move right
        } else if(input_event->key == InputKeyOk) {
            if(app_state->game_select == GameSelectRace) {
                app_state->start_race = true;
            } else if(app_state->game_select == GameSelectDuel) {
                app_state->start_duel = true;
            }
        }
    }

    furi_mutex_release(app_state->mutex);
}

// Allocate and initialize the application state
TownAppState* town_app_state_alloc() {
    TownAppState* app_state = malloc(sizeof(TownAppState));
    if(!app_state) return NULL;

    app_state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    if(!app_state->mutex) {
        free(app_state);
        return NULL;
    }

    app_state->game_select = GameSelectNone;
    app_state->exit = false;
    app_state->start_race = false;
    app_state->start_duel = false;
    app_state->x = 100;
    app_state->y = 20;

    return app_state;
}

int32_t town_app(void* p) {
    UNUSED(p);
    int32_t return_code = 0;

    // Allocate and initialize the application state
    TownAppState* app_state = town_app_state_alloc();
    if(!app_state) return 255;

    // Allocate a new view port
    ViewPort* view_port = view_port_alloc();
    // Set the draw callback function for the view port to `town_render_callback` and pass the application state as context.
    view_port_draw_callback_set(view_port, town_render_callback, app_state);
    // Set the input callback function for the view port to `town_input_callback` and pass the application state as context.
    view_port_input_callback_set(view_port, town_input_callback, app_state);

    // Open the GUI record and add the view port to the GUI in full-screen mode.
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    // Enter an infinite loop that will continue until `app_state->exit` is set to true.
    while(!app_state->exit) {
        if(app_state->start_race) {
            horse_racing_app(NULL);
            app_state->start_race = false;
        } else if(app_state->start_duel) {
            duel_app(NULL);
            app_state->start_duel = false;
        }

        view_port_update(
            view_port); // Updates the view port, causing the render callback to be called.
        furi_delay_ms(80); // Add delay to slow down the loop
    }

    // Clean up resources
    view_port_enabled_set(view_port, false);
    gui_remove_view_port(gui, view_port);
    furi_record_close(RECORD_GUI);
    view_port_free(view_port);
    furi_mutex_free(app_state->mutex);
    free(app_state);

    return return_code; // Returns the return code, which is 0 if everything was successful.
}
