#include "application.h"

#define FIRE_DISPLAY_DURATION_MS 1000
#define MAX_REACTION_WAIT_TIME_MS 5000
#define BACK_BUTTON_HOLD_DURATION_MS 2000

typedef enum {
    DuelGameStateIdle,
    DuelGameStateCountdown,
    DuelGameStateFire,
    DuelGameStateResult,
    DuelGameStateWin,
    DuelGameStateLoose,
    DuelGameStateFalseStart,
} DuelGameState;

typedef struct {
    DuelGameState game_state;
    FuriMutex* mutex;
    bool exit;
    uint32_t countdown_start;
    uint32_t fire_time;
    uint32_t right_shooter_time;
    uint32_t reaction_time;
    bool user_won;
    uint32_t back_button_press_time;
    bool back_button_pressed;
} DuelAppState;

void duel_draw_background(Canvas* canvas) {
    canvas_draw_frame(canvas, 0, 0, FLIPPER_LCD_WIDTH, FLIPPER_LCD_HEIGHT);
    canvas_draw_icon(canvas, 0, 0, &I_duel_background);
}

// Draw icons on the canvas
void duel_draw_icons(Canvas* canvas, const DuelAppState* app_state) {
    // Left Shooter
    const Icon* left_shooter_icon;
    int left_x, left_y;
    if(app_state->game_state == DuelGameStateWin) {
        left_shooter_icon = &I_duel_02;
        left_x = 15;
        left_y = 38;
    } else if(app_state->game_state == DuelGameStateLoose) {
        left_shooter_icon = &I_duel_03;
        left_x = 12;
        left_y = 50;
    } else {
        left_shooter_icon = &I_duel_01;
        left_x = 15;
        left_y = 38;
    }
    canvas_draw_icon(canvas, left_x, left_y, left_shooter_icon);

    // Right Shooter
    const Icon* right_shooter_icon;
    int right_x, right_y;
    if(app_state->game_state == DuelGameStateLoose) {
        right_shooter_icon = &I_duel_12;
        right_x = 105;
        right_y = 38;
    } else if(app_state->game_state == DuelGameStateWin) {
        right_shooter_icon = &I_duel_13;
        right_x = 95;
        right_y = 47;
    } else {
        right_shooter_icon = &I_duel_11;
        right_x = 105;
        right_y = 38;
    }
    canvas_draw_icon(canvas, right_x, right_y, right_shooter_icon);
}

// Draw countdown or result text
void duel_draw_text(Canvas* canvas, DuelAppState* app_state) {
    char buffer[32];
    uint32_t current_time = furi_get_tick();
    uint32_t elapsed = current_time - app_state->countdown_start;

    if(app_state->game_state == DuelGameStateCountdown) {
        if(elapsed < furi_ms_to_ticks(1000)) {
            snprintf(buffer, sizeof(buffer), "READY");
        } else if(elapsed < furi_ms_to_ticks(2500 + rand() % 3500)) {
            snprintf(buffer, sizeof(buffer), "SET");
        } else {
            snprintf(buffer, sizeof(buffer), "FIRE");
            app_state->game_state = DuelGameStateFire;
            app_state->fire_time = current_time;
            app_state->right_shooter_time = current_time + furi_ms_to_ticks(150 + rand() % 1000);
        }
        canvas_draw_str(canvas, 50, 10, buffer);
    } else if(app_state->game_state == DuelGameStateFire) {
        snprintf(buffer, sizeof(buffer), "FIRE");
        canvas_draw_str(canvas, 50, 10, buffer);
        if(current_time >= app_state->right_shooter_time) {
            app_state->user_won = false; // User lost
            app_state->game_state = DuelGameStateLoose;
        } else if(
            (current_time - app_state->fire_time) > furi_ms_to_ticks(MAX_REACTION_WAIT_TIME_MS)) {
            app_state->reaction_time =
                MAX_REACTION_WAIT_TIME_MS; // Set max wait time as reaction time
            app_state->user_won = false; // User lost
            app_state->game_state = DuelGameStateLoose;
        }
    } else if(app_state->game_state == DuelGameStateResult) {
        if(app_state->user_won) {
            app_state->game_state = DuelGameStateWin;
        } else {
            app_state->game_state = DuelGameStateLoose;
        }
    } else if(app_state->game_state == DuelGameStateWin) {
        snprintf(buffer, sizeof(buffer), "WIN! Time: %lu ms", app_state->reaction_time);
        canvas_draw_str(canvas, 20, 10, buffer);
    } else if(app_state->game_state == DuelGameStateLoose) {
        snprintf(buffer, sizeof(buffer), "LOOSE!");
        canvas_draw_str(canvas, 20, 10, buffer);
    } else if(app_state->game_state == DuelGameStateFalseStart) {
        snprintf(buffer, sizeof(buffer), "FALSE START!");
        canvas_draw_str(canvas, 20, 10, buffer);
    }
}

// The render callback function that is called to render the screen.
// This is updated in the main loop through view_port_update
static void app_render_callback(Canvas* const canvas, void* ctx) {
    furi_assert(ctx);
    DuelAppState* app_state = ctx;
    furi_mutex_acquire(app_state->mutex, FuriWaitForever);
    duel_draw_background(canvas);
    duel_draw_icons(canvas, app_state);
    duel_draw_text(canvas, app_state);
    furi_mutex_release(app_state->mutex);
}

// The input callback function that is called when an input event occurs.
static void app_input_callback(InputEvent* input_event, void* ctx) {
    furi_assert(ctx);
    DuelAppState* app_state = ctx;

    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    uint32_t current_time = furi_get_tick();

    if(input_event->type == InputTypePress && input_event->key == InputKeyBack) {
        if(app_state->game_state > DuelGameStateResult) {
            app_state->game_state = DuelGameStateIdle;
        } else {
            app_state->exit = true;
        }
    } else if(input_event->type == InputTypePress && input_event->key == InputKeyOk) {
        if(app_state->game_state == DuelGameStateIdle) {
            app_state->game_state = DuelGameStateCountdown;
            app_state->countdown_start = furi_get_tick();
        } else if(app_state->game_state == DuelGameStateFire) {
            app_state->reaction_time = furi_get_tick() - app_state->fire_time;
            if(furi_get_tick() < app_state->right_shooter_time) {
                app_state->user_won = true; // User won
            } else {
                app_state->user_won = false; // User lost
            }
            app_state->game_state = DuelGameStateResult;
        } else if(app_state->game_state == DuelGameStateCountdown) {
            app_state->game_state = DuelGameStateFalseStart;
        } else if(app_state->game_state > DuelGameStateResult) {
            app_state->exit = true;
        }
    }

    if(input_event->type == InputTypePress && input_event->key == InputKeyBack) {
        app_state->back_button_press_time = current_time;
        app_state->back_button_pressed = true;
    } else if(input_event->type == InputTypeRelease && input_event->key == InputKeyBack) {
        app_state->back_button_pressed = false;
    }

    furi_mutex_release(app_state->mutex);
}

// Allocate and initialize the application state
DuelAppState* duel_app_state_alloc() {
    DuelAppState* app_state = malloc(sizeof(DuelAppState));
    if(!app_state) return NULL;

    app_state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    if(!app_state->mutex) {
        free(app_state);
        return NULL;
    }

    app_state->exit = false;
    app_state->game_state = DuelGameStateIdle;
    app_state->countdown_start = 0;
    app_state->fire_time = 0;
    app_state->right_shooter_time = 0;
    app_state->reaction_time = 0;
    app_state->user_won = false;
    app_state->back_button_press_time = 0;
    app_state->back_button_pressed = false;

    return app_state;
}

int32_t duel_app(void* p) {
    UNUSED(p);
    int32_t return_code = 0;

    // Allocate and initialize the application state
    DuelAppState* app_state = duel_app_state_alloc();
    if(!app_state) return 255;

    // Allocate a new view port
    ViewPort* view_port = view_port_alloc();
    // Set the draw callback function for the view port to `app_render_callback` and pass the application state as context.
    view_port_draw_callback_set(view_port, app_render_callback, app_state);
    // Set the input callback function for the view port to `app_input_callback` and pass the application state as context.
    view_port_input_callback_set(view_port, app_input_callback, app_state);

    // Open the GUI record and add the view port to the GUI in full-screen mode.
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    // Enter an infinite loop that will continue until `app_state->exit` is set to true.
    while(!app_state->exit) {
        uint32_t current_time = furi_get_tick();

        // Transition from FIRE to RESULT after timeout
        if(app_state->game_state == DuelGameStateFire &&
           (current_time - app_state->fire_time) > furi_ms_to_ticks(MAX_REACTION_WAIT_TIME_MS)) {
            app_state->reaction_time = MAX_REACTION_WAIT_TIME_MS;
            app_state->user_won = false; // User lost
            app_state->game_state = DuelGameStateResult;
        }

        // Check if back button is held down
        if(app_state->back_button_pressed && (current_time - app_state->back_button_press_time) >
                                                 furi_ms_to_ticks(BACK_BUTTON_HOLD_DURATION_MS)) {
            app_state->exit = true;
        }

        view_port_update(
            view_port); // Updates the view port, causing the render callback to be called.
        furi_delay_ms(100); // Delays the loop for 100 milliseconds to control the update rate.
    }

    // Clean up resources
    view_port_enabled_set(view_port, false);
    gui_remove_view_port(gui, view_port);
    furi_record_close(RECORD_GUI);
    view_port_free(view_port);
    furi_mutex_free(app_state->mutex);
    free(app_state);

    return return_code; // Returns the return code, which is 0 if everything was successful.
}
