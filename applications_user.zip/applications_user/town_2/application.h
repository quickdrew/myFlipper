#ifndef APPLICATION_H
#define APPLICATION_H

#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <stdlib.h>
#include "town_2_icons.h" // Include the icon header file

#define FLIPPER_LCD_WIDTH 128
#define FLIPPER_LCD_HEIGHT 64

int32_t town_app(void* p);
int32_t horse_racing_app(void* p);
int32_t duel_app(void* p);

#endif // APPLICATION_H
