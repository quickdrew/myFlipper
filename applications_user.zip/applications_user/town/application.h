#ifndef APPLICATION_H
#define APPLICATION_H

#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <stdlib.h>
#include "town_icons.h" // Include the icon header file

#define FLIPPER_LCD_WIDTH 128
#define FLIPPER_LCD_HEIGHT 64
#define FIRE_DISPLAY_DURATION_MS 1000 // 1000 milliseconds (1 second)
#define MAX_REACTION_WAIT_TIME_MS 5000 // 5000 milliseconds (5 seconds)
#define BACK_BUTTON_HOLD_DURATION_MS 2000 // 2000 milliseconds (2 seconds)
#define FINISH_LINE 100

typedef enum {
    GameSelectNone,
    GameSelectRace,
    GameSelectDuel,
} GameSelect;

typedef enum {
    DuelGameStateIdle,
    DuelGameStateCountdown,
    DuelGameStateFire,
    DuelGameStateResult,
    DuelGameStateWin,
    DuelGameStateLoose,
    DuelGameStateFalseStart,
} DuelGameState;

typedef enum {
    RaceGameStateIdle,
    RaceGameStateCountdown,
    RaceGameStateRacing,
    RaceGameStateResult,
} RaceGameState;

typedef struct {
    GameSelect game_select;
    FuriMutex* mutex;
    bool exit;
    int x;
    int y;
    bool start_race;
    uint32_t countdown_start;
    uint32_t fire_time;
    uint32_t right_shooter_time;
    uint32_t reaction_time;
    bool user_won;
    bool new_high_score;
    uint32_t back_button_press_time;
    bool back_button_pressed;
    int player_progress;
    int cpu_progress;
    DuelGameState game_state;
} DuelAppState;

typedef struct {
    RaceGameState game_state;
    FuriMutex* mutex;
    uint32_t countdown_start;
    uint32_t race_start;
    uint32_t race_end;
    uint32_t text_delay;
    int player_progress;
    int cpu_progress;
    bool new_high_score;
    bool countdown_finished;
    bool exit;
    uint32_t animation_frame;
} RacingAppState;

typedef struct {
    GameSelect game_select;
    FuriMutex* mutex;
    bool exit;
    int x;
    int y;
    bool start_race;
    bool start_duel;
} TownAppState;

// Function prototypes
DuelAppState* duel_app_state_alloc();
RacingAppState* racing_app_state_alloc();
TownAppState* town_app_state_alloc();
int32_t town_app(void* p);
int32_t horse_racing_app(void* p);
int32_t duel_app(void* p);

#endif // APPLICATION_H
