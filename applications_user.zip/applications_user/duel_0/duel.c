#include "application.h"
#include <furi_hal.h>
#include <storage/storage.h>

#define FLIPPER_LCD_WIDTH 128
#define FLIPPER_LCD_HEIGHT 64

// Define the duration to keep "FIRE" displayed
#define FIRE_DISPLAY_DURATION_MS 1000 // 1000 milliseconds (1 second)
// Define the maximum duration to wait for user input after "FIRE" is displayed
#define MAX_REACTION_WAIT_TIME_MS 5000 // 5000 milliseconds (5 seconds)
// Define the duration to detect holding down the back button
#define BACK_BUTTON_HOLD_DURATION_MS 2000 // 2000 milliseconds (2 seconds)

#define HIGH_SCORE_FILE_PATH "/int/high_score.txt"

// Load the high score from persistent storage
void load_high_score(AppState* app_state) {
    Storage* storage = furi_record_open(RECORD_STORAGE);
    File* file = storage_file_alloc(storage);
    if(storage_file_open(file, HIGH_SCORE_FILE_PATH, FSAM_READ, FSOM_OPEN_EXISTING)) {
        storage_file_read(file, &app_state->high_score, sizeof(app_state->high_score));
        storage_file_close(file);
    } else {
        app_state->high_score = 0; // Initialize high score to 0 if file doesn't exist
    }
    storage_file_free(file);
    furi_record_close(RECORD_STORAGE);
}

// Save the high score to persistent storage
void save_high_score(AppState* app_state) {
    Storage* storage = furi_record_open(RECORD_STORAGE);
    File* file = storage_file_alloc(storage);
    if(storage_file_open(file, HIGH_SCORE_FILE_PATH, FSAM_WRITE, FSOM_OPEN_ALWAYS)) {
        storage_file_write(file, &app_state->high_score, sizeof(app_state->high_score));
        storage_file_close(file);
    }
    storage_file_free(file);
    furi_record_close(RECORD_STORAGE);
}

// Draw the background frame
void draw_background(Canvas* canvas) {
    canvas_draw_frame(canvas, 0, 0, FLIPPER_LCD_WIDTH, FLIPPER_LCD_HEIGHT);
}

// Draw icons on the canvas
void draw_icons(Canvas* canvas, const AppState* app_state) {
    canvas_draw_icon(canvas, 0, 0, &I_background);

    // Left Shooter
    const Icon* left_shooter_icon;
    int left_x, left_y;
    if(app_state->game_state == GameStateWin) {
        left_shooter_icon = &I_duel_02;
        left_x = 15;
        left_y = 38;
    } else if(app_state->game_state == GameStateLoose) {
        left_shooter_icon = &I_duel_03;
        left_x = 12;
        left_y = 50;
    } else {
        left_shooter_icon = &I_duel_01;
        left_x = 15;
        left_y = 38;
    }
    canvas_draw_icon(canvas, left_x, left_y, left_shooter_icon);

    // Right Shooter
    const Icon* right_shooter_icon;
    int right_x, right_y;
    if(app_state->game_state == GameStateLoose) {
        right_shooter_icon = &I_duel_12;
        right_x = 105;
        right_y = 38;
    } else if(app_state->game_state == GameStateWin) {
        right_shooter_icon = &I_duel_13;
        right_x = 95;
        right_y = 47;
    } else {
        right_shooter_icon = &I_duel_11;
        right_x = 105;
        right_y = 38;
    }
    canvas_draw_icon(canvas, right_x, right_y, right_shooter_icon);
}

// Draw countdown or result text
void draw_text(Canvas* canvas, AppState* app_state) {
    char buffer[32];
    uint32_t current_time = furi_get_tick();
    uint32_t elapsed = current_time - app_state->countdown_start;

    if(app_state->game_state == GameStateCountdown) {
        if(elapsed < furi_ms_to_ticks(1000)) {
            snprintf(buffer, sizeof(buffer), "READY");
        } else if(elapsed < furi_ms_to_ticks(2500 + rand() % 3500)) {
            snprintf(buffer, sizeof(buffer), "SET");
        } else {
            snprintf(buffer, sizeof(buffer), "FIRE");
            app_state->game_state = GameStateFire;
            app_state->fire_time = current_time;
            // Set random delay for right shooter between 500ms and 3000ms
            app_state->right_shooter_time = current_time + furi_ms_to_ticks(150 + rand() % 1000);
        }
        canvas_draw_str(canvas, 50, 10, buffer);
    } else if(app_state->game_state == GameStateFire) {
        snprintf(buffer, sizeof(buffer), "FIRE");
        canvas_draw_str(canvas, 50, 10, buffer);
        if(current_time >= app_state->right_shooter_time) {
            app_state->user_won = false; // User lost
            app_state->game_state = GameStateLoose;
        } else if(
            (current_time - app_state->fire_time) > furi_ms_to_ticks(MAX_REACTION_WAIT_TIME_MS)) {
            app_state->reaction_time =
                MAX_REACTION_WAIT_TIME_MS; // Set max wait time as reaction time
            app_state->user_won = false; // User lost
            app_state->game_state = GameStateLoose;
        }
    } else if(app_state->game_state == GameStateResult) {
        if(app_state->user_won) {
            app_state->game_state = GameStateWin;
        } else {
            app_state->game_state = GameStateLoose;
        }
    } else if(app_state->game_state == GameStateWin) {
        snprintf(buffer, sizeof(buffer), "WIN! Time: %lu ms", app_state->reaction_time);
        canvas_draw_str(canvas, 20, 10, buffer);
    } else if(app_state->game_state == GameStateLoose) {
        snprintf(buffer, sizeof(buffer), "LOOSE!");
        canvas_draw_str(canvas, 20, 10, buffer);
    } else if(app_state->game_state == GameStateFalseStart) {
        snprintf(buffer, sizeof(buffer), "FALSE START!");
        canvas_draw_str(canvas, 20, 10, buffer);
    }

    // // Display high score
    // snprintf(buffer, sizeof(buffer), "High Score: %lu ms", app_state->high_score);
    // canvas_draw_str(canvas, 10, 50, buffer);

    // Display new high score text if applicable
    if(app_state->new_high_score) {
        canvas_draw_str(canvas, 10, 40, "New High Score!");
    }
}

// The render callback function that is called to render the screen.
// This is updated in the main loop through view_port_update
static void app_render_callback(Canvas* const canvas, void* ctx) {
    furi_assert(ctx);
    AppState* app_state = ctx;
    furi_mutex_acquire(app_state->mutex, FuriWaitForever);
    draw_background(canvas);
    draw_icons(canvas, app_state);
    draw_text(canvas, app_state);
    furi_mutex_release(app_state->mutex);
}

// The input callback function that is called when an input event occurs.
static void app_input_callback(InputEvent* input_event, void* ctx) {
    furi_assert(ctx);
    AppState* app_state = ctx;

    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    uint32_t current_time = furi_get_tick();

    if(input_event->type == InputTypePress && input_event->key == InputKeyBack) {
        if(app_state->game_state > GameStateResult) {
            app_state->game_state = GameStateIdle;
        } else {
            app_state->exit = true;
        }
    } else if(input_event->type == InputTypePress && input_event->key == InputKeyOk) {
        if(app_state->game_state == GameStateIdle) {
            app_state->game_state = GameStateCountdown;
            app_state->countdown_start = furi_get_tick();
        } else if(app_state->game_state == GameStateFire) {
            app_state->reaction_time = furi_get_tick() - app_state->fire_time;
            if(furi_get_tick() < app_state->right_shooter_time) {
                app_state->user_won = true; // User won
            } else {
                app_state->user_won = false; // User lost
            }
            app_state->game_state = GameStateResult;

            // Check if the user achieved a new high score
            if(app_state->user_won &&
               (app_state->reaction_time < app_state->high_score || app_state->high_score == 0)) {
                app_state->high_score = app_state->reaction_time;
                app_state->new_high_score = true;
                save_high_score(app_state);
            } else {
                app_state->new_high_score = false;
            }
        } else if(app_state->game_state == GameStateCountdown) {
            // Handle false start
            app_state->game_state = GameStateFalseStart;
        }
    }

    if(input_event->type == InputTypePress && input_event->key == InputKeyBack) {
        app_state->back_button_press_time = current_time;
        app_state->back_button_pressed = true;
    } else if(input_event->type == InputTypeRelease && input_event->key == InputKeyBack) {
        app_state->back_button_pressed = false;
    }

    furi_mutex_release(app_state->mutex);
}

// Allocate and initialize the application state
AppState* app_state_alloc() {
    AppState* app_state = malloc(sizeof(AppState));
    if(!app_state) return NULL;

    app_state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    if(!app_state->mutex) {
        free(app_state);
        return NULL;
    }

    app_state->exit = false;
    app_state->game_state = GameStateIdle;
    app_state->countdown_start = 0;
    app_state->fire_time = 0;
    app_state->right_shooter_time = 0;
    app_state->reaction_time = 0;
    app_state->user_won = false;
    app_state->high_score = 0;
    app_state->new_high_score = false;
    app_state->back_button_press_time = 0;
    app_state->back_button_pressed = false;

    return app_state;
}

int32_t app_main(void* p) {
    UNUSED(p);
    int32_t return_code = 0;

    // Allocate and initialize the application state
    AppState* app_state = app_state_alloc();
    if(!app_state) return 255;

    // Load the high score
    load_high_score(app_state);

    // Allocate a new view port
    ViewPort* view_port = view_port_alloc();
    // Set the draw callback function for the view port to `app_render_callback` and pass the application state as context.
    view_port_draw_callback_set(view_port, app_render_callback, app_state);
    // Set the input callback function for the view port to `app_input_callback` and pass the application state as context.
    view_port_input_callback_set(view_port, app_input_callback, app_state);

    // Open the GUI record and add the view port to the GUI in full-screen mode.
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    // Enter an infinite loop that will continue until `app_state->exit` is set to true.
    while(!app_state->exit) {
        uint32_t current_time = furi_get_tick();

        // Transition from FIRE to RESULT after timeout
        if(app_state->game_state == GameStateFire &&
           (current_time - app_state->fire_time) > furi_ms_to_ticks(MAX_REACTION_WAIT_TIME_MS)) {
            app_state->reaction_time = MAX_REACTION_WAIT_TIME_MS;
            app_state->user_won = false; // User lost
            app_state->game_state = GameStateResult;

            // Check if the user achieved a new high score
            if(app_state->user_won &&
               (app_state->reaction_time < app_state->high_score || app_state->high_score == 0)) {
                app_state->high_score = app_state->reaction_time;
                app_state->new_high_score = true;
                save_high_score(app_state);
            } else {
                app_state->new_high_score = false;
            }
        }

        // Check if back button is held down
        if(app_state->back_button_pressed && (current_time - app_state->back_button_press_time) >
                                                 furi_ms_to_ticks(BACK_BUTTON_HOLD_DURATION_MS)) {
            app_state->exit = true;
        }

        view_port_update(
            view_port); // Updates the view port, causing the render callback to be called.
        furi_delay_ms(100); // Delays the loop for 100 milliseconds to control the update rate.
    }

    // Clean up resources
    view_port_enabled_set(view_port, false);
    gui_remove_view_port(gui, view_port);
    furi_record_close(RECORD_GUI);
    view_port_free(view_port);
    furi_mutex_free(app_state->mutex);
    free(app_state);

    return return_code; // Returns the return code, which is 0 if everything was successful.
}
