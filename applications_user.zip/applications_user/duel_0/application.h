#ifndef APPLICATION_H
#define APPLICATION_H

#include <stdlib.h>
#include <furi.h>
#include <gui/gui.h>
#include <input/input.h>
#include "duel_icons.h"
#include <furi_hal.h>
#include <storage/storage.h>

// Game states
typedef enum {
    GameStateIdle,
    GameStateCountdown,
    GameStateFire,
    GameStateMeasure,
    GameStateResult,
    GameStateWin,
    GameStateLoose,
    GameStateFalseStart // New state for handling false starts
} GameState;

typedef struct {
    FuriMutex* mutex; // Mutex for synchronizing access to shared resources.
    bool exit; // Flag to indicate when to exit the application.
    GameState game_state; // Current state of the game
    uint32_t countdown_start; // Timestamp when countdown starts
    uint32_t fire_time; // Timestamp when "fire" is shown
    uint32_t right_shooter_time; // Timestamp when right shooter is triggered
    uint32_t reaction_time; // Time difference between "fire" and clicking "ok"
    uint32_t high_score; // The best reaction time recorded
    bool user_won; // Flag to indicate if the user won
    uint32_t back_button_press_time; // Timestamp when back button is pressed
    bool back_button_pressed; // Flag to indicate if back button is being pressed
    bool new_high_score; // Flag to indicate if a new high score was achieved
} AppState;

// Menu state structure
typedef struct {
    FuriMutex* mutex; // Mutex for synchronizing access to shared resources.
    bool exit; // Flag to indicate when to exit the application.
    bool start_game; // Flag to indicate when to start the game.
    uint32_t high_score; // The best reaction time recorded
} MenuState;

// Function to render the main menu
void main_menu_render(Canvas* canvas, const MenuState* menu_state);

// Function to handle input in the main menu
void main_menu_input(InputEvent* input_event, MenuState* menu_state);

// Allocate and initialize the application state
AppState* app_state_alloc(void);

// Draw the background frame
void draw_background(Canvas* canvas);

// Draw icons on the canvas
void draw_icons(Canvas* canvas, const AppState* app_state);

// Draw countdown or result text
void draw_text(Canvas* canvas, AppState* app_state);

// Load the high score from persistent storage
void load_high_score(AppState* app_state);

// Save the high score to persistent storage
void save_high_score(AppState* app_state);

// Declaration of app_main function
int32_t app_main(void* p);

#endif // APPLICATION_H
