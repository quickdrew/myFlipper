#include "application.h"

// Draw the main menu
void draw_main_menu(Canvas* canvas, const MenuState* menu_state) {
    canvas_clear(canvas);
    canvas_set_font(canvas, FontPrimary);
    canvas_draw_str(canvas, 10, 10, "Flipper Zero Game");
    canvas_draw_str(canvas, 10, 30, "Press OK to Start");

    // Display high score
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "High Score: %lu ms", menu_state->high_score);
    canvas_draw_str(canvas, 10, 50, buffer);
}

// The render callback function that is called to render the menu screen.
static void menu_render_callback(Canvas* const canvas, void* ctx) {
    furi_assert(ctx);
    MenuState* menu_state = ctx;
    furi_mutex_acquire(menu_state->mutex, FuriWaitForever);
    draw_main_menu(canvas, menu_state);
    furi_mutex_release(menu_state->mutex);
}

// The input callback function that is called when an input event occurs in the menu.
static void menu_input_callback(InputEvent* input_event, void* ctx) {
    furi_assert(ctx);
    MenuState* menu_state = ctx;

    furi_mutex_acquire(menu_state->mutex, FuriWaitForever);

    if(input_event->type == InputTypePress && input_event->key == InputKeyBack) {
        menu_state->exit = true;
    } else if(input_event->type == InputTypePress && input_event->key == InputKeyOk) {
        menu_state->start_game = true;
    }

    furi_mutex_release(menu_state->mutex);
}

// Allocate and initialize the menu state
MenuState* menu_state_alloc(uint32_t high_score) {
    MenuState* menu_state = malloc(sizeof(MenuState));
    if(!menu_state) return NULL;

    menu_state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    if(!menu_state->mutex) {
        free(menu_state);
        return NULL;
    }

    menu_state->exit = false;
    menu_state->start_game = false;
    menu_state->high_score = high_score;

    return menu_state;
}

// The entry point for the main menu
int32_t main_menu(void* p) {
    UNUSED(p);
    int32_t return_code = 0;

    // Load the high score
    AppState temp_state;
    load_high_score(&temp_state);

    // Allocate and initialize the menu state
    MenuState* menu_state = menu_state_alloc(temp_state.high_score);
    if(!menu_state) return 255;

    // Allocate a new view port
    ViewPort* view_port = view_port_alloc();
    // Set the draw callback function for the view port to `menu_render_callback` and pass the menu state as context.
    view_port_draw_callback_set(view_port, menu_render_callback, menu_state);
    // Set the input callback function for the view port to `menu_input_callback` and pass the menu state as context.
    view_port_input_callback_set(view_port, menu_input_callback, menu_state);

    // Open the GUI record and add the view port to the GUI in full-screen mode.
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    // Enter an infinite loop that will continue until `menu_state->exit` is set to true.
    while(!menu_state->exit) {
        if(menu_state->start_game) {
            // Start the game
            app_main(NULL);
            menu_state->start_game = false;
            // Reload high score after game
            load_high_score(&temp_state);
            menu_state->high_score = temp_state.high_score;
        }

        view_port_update(
            view_port); // Updates the view port, causing the render callback to be called.
        furi_delay_ms(100); // Delays the loop for 100 milliseconds to control the update rate.
    }

    // Clean up resources
    view_port_enabled_set(view_port, false);
    gui_remove_view_port(gui, view_port);
    furi_record_close(RECORD_GUI);
    view_port_free(view_port);
    furi_mutex_free(menu_state->mutex);
    free(menu_state);

    return return_code; // Returns the return code, which is 0 if everything was successful.
}
