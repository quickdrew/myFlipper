#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <stdlib.h>
#include "RoundUp_icons.h" // Include the icon header file

#define FLIPPER_LCD_WIDTH 128
#define FLIPPER_LCD_HEIGHT 64

typedef enum { GameStateIdle, GameStateRoundUp } GameState;

typedef struct {
    int x;
    int y;
} Point;

typedef struct {
    Point A;
    Point B;
} Cows;

typedef struct {
    GameState game_state;
    FuriMutex* mutex;
    bool exit;
    Cows cow;
    int pos_x; //Player positon x and y
    int pos_y;
} AppState;

// Draw the background frame
static void draw_background(Canvas* canvas) {
    canvas_draw_frame(canvas, 0, 0, FLIPPER_LCD_WIDTH, FLIPPER_LCD_HEIGHT);

    canvas_draw_icon(canvas, 0, 0, &I_RoundUp_background);
}

void draw_player(Canvas* canvas, const AppState* app_state) {
    const Icon* player_icon;
    char buffer[32];

    player_icon = &I_RoundUp_player;
    canvas_draw_icon(canvas, app_state->pos_x, app_state->pos_y, player_icon);
    snprintf(buffer, sizeof(buffer), "Position %i, %i", app_state->pos_y, app_state->pos_y);
    canvas_draw_str(canvas, 10, 10, buffer);
}

void draw_cows(Canvas* canvas, const AppState* app_state) {
    const Icon* cow_A_icon;
    const Icon* cow_B_icon;

    cow_A_icon = &I_cow;
    cow_B_icon = &I_cow;
    canvas_draw_icon(canvas, app_state->cow.A.x, app_state->cow.A.y, cow_A_icon);
    canvas_draw_icon(canvas, app_state->cow.B.x, app_state->cow.B.y, cow_B_icon);
}

static void RoundUp_app_render_callback(Canvas* const canvas, void* ctx) {
    furi_assert(ctx);
    AppState* app_state = ctx;
    furi_mutex_acquire(app_state->mutex, FuriWaitForever);

    draw_background(canvas);
    draw_player(canvas, app_state);
    draw_cows(canvas, app_state);
    //draw_text(canvas, app_state);

    furi_mutex_release(app_state->mutex);
}

static void RoundUp_app_input_callback(InputEvent* input_event, void* ctx) {
    furi_assert(ctx);
    AppState* app_state = ctx;

    furi_mutex_acquire(app_state->mutex, FuriWaitForever);
    if(input_event->type == InputTypePress || input_event->type == InputTypeRepeat) {
        if(input_event->key == InputKeyBack) {
            app_state->exit = true;
        }
    }

    furi_mutex_release(app_state->mutex);
}

AppState* RoundUp_app_state_alloc() {
    AppState* app_state = malloc(sizeof(AppState));
    if(!app_state) return NULL;

    app_state->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    if(!app_state->mutex) {
        free(app_state);
        return NULL;
    }

    app_state->game_state = GameStateIdle;
    app_state->exit = false;

    // Player starting position
    app_state->pos_x = 100;
    app_state->pos_y = 30;
    // Cow starting position
    app_state->cow.A.x = 10;
    app_state->cow.A.y = 10;
    app_state->cow.B.x = 20;
    app_state->cow.B.y = 20;

    return app_state;
}

int32_t RoundUp_app(void* p) {
    UNUSED(p);
    int32_t return_code = 0;

    // Allocate and initialize the application state
    AppState* app_state = RoundUp_app_state_alloc();
    if(!app_state) return 255;

    ViewPort* view_port = view_port_alloc();
    view_port_draw_callback_set(view_port, RoundUp_app_render_callback, app_state);
    view_port_input_callback_set(view_port, RoundUp_app_input_callback, app_state);

    // Open the GUI record and add the view port to the GUI in full-screen mode.
    Gui* gui = furi_record_open(RECORD_GUI);
    gui_add_view_port(gui, view_port, GuiLayerFullscreen);

    // Enter an infinite loop that will continue until `app_state->exit` is set to true.
    while(!app_state->exit) {
        view_port_update(
            view_port); // Updates the view port, causing the render callback to be called.
        furi_delay_ms(80); // Add delay to slow down the loop
    }

    // Clean up resources
    view_port_enabled_set(view_port, false);
    gui_remove_view_port(gui, view_port);
    furi_record_close(RECORD_GUI);
    view_port_free(view_port);
    furi_mutex_free(app_state->mutex);
    free(app_state);

    return return_code; // Returns the return code, which is 0 if everything was successful.
}